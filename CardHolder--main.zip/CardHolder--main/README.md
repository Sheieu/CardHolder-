# CardHolder-
Bu shaxsiy kartam uchun baza manbai

## Xususiyatlar
- Kredit kartalarni boshqarish
- Foydalanuvchi xavfsizligi
- Ma’lumotlarni shifrlash

## Ishlatish
1. Repository-ni klonlang:
   ```bash
   git clone https://github.com/Sheieu/CardHolder.git
